<!DOCTYPE html>
<html>
<head>
  <title>Hola Mundo</title>
  <style>
    body { 
      background: #1566d2; 
      color: blue; 
      font-size: 2em; 
      text-align: center; 
      padding-top: 20%; 
      font-family: Arial, sans-serif;
    }
  </style>
</head>
<body>
  hola mundo
</body>
</html>
