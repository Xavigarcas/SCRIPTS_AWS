<!DOCTYPE html>
<html>
<head>
    <title>PHP funcionando</title>
    <style>
        body {
            background-color: #74D674; /* Verde claro */
            margin: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .centered {
            font-size: 1.5em;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="centered">
        <?php echo "Hola Mundo"; ?>
    </div>
</body>
</html>
